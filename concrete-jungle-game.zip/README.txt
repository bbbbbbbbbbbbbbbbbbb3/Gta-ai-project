CONCRETE JUNGLE — BROWSER BUILD

This ZIP contains the static browser build of Concrete Jungle.
Extract the files and serve this folder with a local web server or static web host.
For VR, use HTTPS or localhost; opening index.html with file:// does not enable WebXR.
